package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingBean {
	@FindBy(how = How.NAME, name = "userName") // FindBy used to locate webElements
	private WebElement userName;
	@FindBy(how = How.NAME, name = "userPwd") // FindBy used to locate webElements
	private WebElement userPassword;
	@FindBy(how = How.CLASS_NAME, className = "btn") // FindBy used to locate webElements
	private WebElement loginButton;

	@FindBy(how = How.ID, id = "txtFirstName") // FindBy used to locate webElements
	private WebElement firstName;
	@FindBy(how = How.NAME, name = "txtLN") // FindBy used to locate webElements
	private WebElement lastName;
	@FindBy(how = How.NAME, name = "Email") // FindBy used to locate webElements
	private WebElement email;
	@FindBy(how = How.NAME, name = "Phone") // FindBy used to locate webElements
	private WebElement mobile;
	@FindBy(how = How.TAG_NAME, tagName = "textarea") // FindBy used to locate webElements
	private WebElement address;
	@FindBy(how = How.ID, id = "btnPayment") // FindBy used to locate webElements
	private WebElement confirmBooking;
	// drop down
	@FindBy(how = How.NAME, name = "city")
	private WebElement city;

	@FindBy(how = How.NAME, name = "state")
	private WebElement state;
	@FindBy(how = How.NAME, name = "persons")
	private WebElement noOfPerson;

	@FindBy(how = How.ID, id = "txtCardholderName") // FindBy used to locate webElements
	private WebElement cardHolderName;
	@FindBy(how = How.ID, id = "txtDebit") // FindBy used to locate webElements
	private WebElement cardNumber;
	@FindBy(how = How.ID, id = "txtCvv") // FindBy used to locate webElements
	private WebElement cvv;
	@FindBy(how = How.ID, id = "txtMonth") // FindBy used to locate webElements
	private WebElement expiryMonth;
	@FindBy(how = How.ID, id = "txtYear") // FindBy used to locate webElements
	private WebElement expiryYear;

	public void clickLoginButton() {
		loginButton.click();
	}

	public void setAddress(String address) {
		this.address.clear();
		this.address.sendKeys(address);
	}

	public String getUserName() {
		return userName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.userName.clear();
		this.userName.sendKeys(userName);
	}

	public String getUserPassword() {
		return userPassword.getAttribute("value");
	}

	public void setUserPassword(String userPassword) {
		this.userPassword.clear();
		this.userPassword.sendKeys(userPassword);
	}

	public void clickConfirmBooking() {
		confirmBooking.click();
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.clear();
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.clear();
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public String getMobile() {
		return mobile.getAttribute("value");
	}

	public void setMobile(String mobile) {
		this.mobile.clear();
		this.mobile.sendKeys(mobile);
	}

	public String getCardHolderName() {
		return cardHolderName.getAttribute("value");
	}

	public void setCardHolderName(String name) {
		this.cardHolderName.clear();
		this.cardHolderName.sendKeys(name);
	}

	public String getCardNumber() {
		return cardNumber.getAttribute("value");
	}

	public void setCardNumber(String number) {
		this.cardNumber.clear();
		this.cardNumber.sendKeys(number);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.clear();
		this.cvv.sendKeys(cvv);
	}

	public String getExpiryMonth() {
		return expiryMonth.getAttribute("value");
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.clear();
		this.expiryMonth.sendKeys(expiryMonth);
	}

	public String getExpiryYear() {
		return expiryYear.getAttribute("value");
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.clear();
		this.expiryYear.sendKeys(expiryYear);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getNumberOfPerson() {
		return new Select(this.noOfPerson).getFirstSelectedOption().getText();
	}

	public void setNumberOfPerson(String noOfPerson) {
		new Select(this.noOfPerson).selectByVisibleText(noOfPerson);
	}
}
