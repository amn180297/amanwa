package com.cg.step;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.HotelBookingBean;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {
	private WebDriver driver;
	private HotelBookingBean hotelBookingBean;
	private Logger log = Logger.getLogger(HotelBookingStepDefinition.class.getName());

	@Given("^I opened Login Page$")
	public void i_opened_Login_Page() throws Throwable {
		driver = new DriverUtil().getDriver("chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		String loginFile = "file:" + System.getProperty("user.dir") + "//WebContent//login.html";
		driver.get(loginFile);
		hotelBookingBean = new HotelBookingBean();
		PageFactory.initElements(driver, hotelBookingBean); // Factory Class to use Page Object
		log.info("Login Page Opened");
	}

	@When("^I clicked 'Login' without entering 'UserName'$")
	public void i_clicked_Login_without_entering_UserName() throws Throwable {
		hotelBookingBean.clickLoginButton();
		log.info("I clicked 'Login' without entering 'UserName'");
	}

	@Then("^display message  'Please enter userName'$")
	public void display_message_Please_enter_userName() throws Throwable {
		log.info("display message  'Please enter userName'");
	}

	@When("^I clicked 'Login' without entering 'Password'$")
	public void i_clicked_Login_without_entering_Password() throws Throwable {
		hotelBookingBean.setUserName("capgemini");
		hotelBookingBean.clickLoginButton();
		log.info("I clicked 'Login' without entering 'Password'");
	}

	@Then("^display message  'Please enter password'$")
	public void display_message_Please_enter_password() throws Throwable {
		log.info("display message  'Please enter password'");
	}

	@When("^I clicked 'Login' after entering credentials$")
	public void i_clicked_Login_after_entering_credentials() throws Throwable {
		hotelBookingBean.setUserName("capgemini");
		hotelBookingBean.setUserPassword("capg1234");
		log.info("I clicked 'Login' after entering credentials");
	}

	@Then("^Login is successfull$")
	public void login_is_successfull() throws Throwable {
		hotelBookingBean.clickLoginButton();
		log.info("Login is successfull");
	}

	@When("^I clicked 'confirm Booking' without entering 'FirstName'$")
	public void i_clicked_confirm_Booking_without_entering_FirstName() throws Throwable {
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'FirstName'");
	}

	@Then("^display message  'Please fill the First Name'$")
	public void display_message_Please_fill_the_First_Name() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the First Name'");
	}

	@When("^I clicked 'confirm Booking' without entering 'LastName'$")
	public void i_clicked_confirm_Booking_without_entering_LastName() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'LastName'");

	}

	@Then("^display message  'Please fill the Last Name'$")
	public void display_message_Please_fill_the_Last_Name() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the Last Name'");
	}

	@When("^I clicked 'confirm Booking' without entering 'Email'$")
	public void i_clicked_confirm_Booking_without_entering_Email() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Email'");
	}

	@Then("^display message  'Please fill the Email'$")
	public void display_message_Please_fill_the_Email() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the Email";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the Email'");
	}

	@When("^I clicked 'confirm Booking' with invalid 'Email'$")
	public void i_clicked_confirm_Booking_with_invalid_Email() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vigmail.com");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' with invalid 'Email'");
	}

	@Then("^display message  'Please enter valid Email Id\\.'$")
	public void display_message_Please_enter_valid_Email_Id() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please enter valid Email Id");
	}

	@When("^I clicked 'confirm Booking' without entering 'Mobile'$")
	public void i_clicked_confirm_Booking_without_entering_Mobile() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Mobile'");
	}

	@Then("^display message  'Please fill the Mobile No\\.'$")
	public void display_message_Please_fill_the_Mobile_No() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the Mobile No.";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the Mobile No");
	}

	@When("^I clicked 'confirm Booking' with invalid 'Mobile'$")
	public void i_clicked_confirm_Booking_with_invalid_Mobile() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("12365478");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' with invalid 'Mobile'");
	}

	@Then("^display message  'Please enter valid Contact no\\.'$")
	public void display_message_Please_enter_valid_Contact_no() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please enter valid Contact no");
	}

	@When("^I clicked 'confirm Booking' without selecting 'City'$")
	public void i_clicked_confirm_Booking_without_selecting_City() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without selecting 'City'");
	}

	@Then("^display message  'Please select city'$")
	public void display_message_Please_select_city() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please select city";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please select city'");
	}

	@When("^I clicked 'confirm Booking' without selecting 'state'$")
	public void i_clicked_confirm_Booking_without_selecting_state() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without selecting 'state'");
	}

	@Then("^display message  'Please select state'$")
	public void display_message_Please_select_state() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please select state";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please select state'");
	}

	@When("^I clicked 'confirm Booking' without selecting 'Number Of People'$")
	public void i_clicked_confirm_Booking_without_selecting_Number_Of_People() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without selecting 'Number Of People'");
	}

	@Then("^display message  'Please fill the Number of people attending'$")
	public void display_message_Please_fill_the_Number_of_people_attending() throws Throwable {
		assertTrue(true);
		log.info("display message  'Please fill the Number of people attending'");
	}

	@When("^I clicked 'confirm Booking' without entering 'Card Holder Name'$")
	public void i_clicked_confirm_Booking_without_entering_Card_Holder_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Card Holder Name'");
	}

	@Then("^display message  'Please fill the Card holder name'$")
	public void display_message_Please_fill_the_Card_holder_name() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the Card holder name";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the Card holder name'");
	}

	@When("^I clicked 'confirm Booking' without entering 'Debit Card Number'$")
	public void i_clicked_confirm_Booking_without_entering_Debit_Card_Number() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.setCardHolderName("Vikash Kumar");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Debit Card Number'");
	}

	@Then("^display message  'Please fill the Debit card Number'$")
	public void display_message_Please_fill_the_Debit_card_Number() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the Debit card Number";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the Debit card Number'");
	}

	@When("^I clicked 'confirm Booking' without entering 'CVV'$")
	public void i_clicked_confirm_Booking_without_entering_CVV() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.setCardHolderName("Vikash Kumar");
		hotelBookingBean.setCardNumber("963258741236547");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'CVV'");
	}

	@Then("^display message  'Please fill the CVV'$")
	public void display_message_Please_fill_the_CVV() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the CVV";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the CVV'");
	}

	@When("^I clicked 'confirm Booking' without entering 'Expiration month'$")
	public void i_clicked_confirm_Booking_without_entering_Expiration_month() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.setCardHolderName("Vikash Kumar");
		hotelBookingBean.setCardNumber("963258741236547");
		hotelBookingBean.setCvv("3214");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Expiration month'");
	}

	@Then("^display message  'Please fill expiration month'$")
	public void display_message_Please_fill_expiration_month() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill expiration month";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill expiration month'");
	}

	@When("^I clicked 'confirm Booking' without entering 'Expiration year'$")
	public void i_clicked_confirm_Booking_without_entering_Expiration_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.setCardHolderName("Vikash Kumar");
		hotelBookingBean.setCardNumber("963258741236547");
		hotelBookingBean.setCvv("3214");
		hotelBookingBean.setExpiryMonth("january");
		hotelBookingBean.clickConfirmBooking();
		log.info("I clicked 'confirm Booking' without entering 'Expiration year'");
	}

	@Then("^display message  'Please fill the expiration year'$")
	public void display_message_Please_fill_the_expiration_year() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText(); // takes the alertbox text
		String expectedMessage = "Please fill the expiration year";
		Assert.assertEquals(expectedMessage, actualMessage);
		log.info("display message  'Please fill the expiration year'");
	}

	@When("^I have entered all the details correct$")
	public void i_have_entered_all_the_details_correct() throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBookingBean.setFirstName("Vikash");
		hotelBookingBean.setLastName("Kumar");
		hotelBookingBean.setEmail("vikash@gmail.com");
		hotelBookingBean.setMobile("9852993617");
		hotelBookingBean.setAddress("Gowlidoddy,Hyderabad");
		hotelBookingBean.setCity("Pune");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setNumberOfPerson("5");
		hotelBookingBean.setCardHolderName("Vikash Kumar");
		hotelBookingBean.setCardNumber("963258741236547");
		hotelBookingBean.setCvv("3214");
		hotelBookingBean.setExpiryMonth("january");
		hotelBookingBean.setExpiryYear("2023");
		hotelBookingBean.clickConfirmBooking();
		log.info("I have entered all the details correct");
	}

	@Then("^Move to booking successfull page$")
	public void move_to_booking_successfull_page() throws Throwable {
		Thread.sleep(3000);
		log.info("Move to booking successfull page");
		new DriverUtil().closeDriver(driver);
	}
}
